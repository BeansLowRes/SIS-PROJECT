<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\StudentModel;

class Students extends BaseController
{
    public function index(): string
    {
        $model = new StudentModel();
        $data = ['students' => $model->findAll()];
        return view ('students/index', $data);
    }
    public function new() {
        return view('students/new');
    }
    public function create() {
        $model = new StudentModel();

        $data = $this->request->getPost([
            'name',
            'course',
            'student_no',
            'email'
        ]);

        if(!$model->insert($data)) {
            return redirect()->back()
            ->withInput()
            ->with('errors', $model->errors());
        }
        return redirect()->to(site_url('students'))
        ->with('message', 'Student Added Successfully');
    }
}
