<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('students', 'Students::index');
$routes->get('students/new', 'Students::new');
$routes->post('students', 'Students::create');

$routes->get(
    'students(:num)', 'Students::edit/$1'
);
$routes->post(
    'students/(:num)', 'Students::update/$1'
);
$routes->post(
    'students/(:num)/delete', 'Students::delete/$1'
);
