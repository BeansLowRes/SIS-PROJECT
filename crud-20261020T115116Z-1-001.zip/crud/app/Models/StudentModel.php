<?php 
namespace App\Models;

use CodeIgniter\Model;

class StudentModel extends Model
{

    protected $table = 'students';
    protected $primary = 'id';
    protected $returnType ='array';
    protected $allowedFields = ['name','course', 'student_no', 'email'];

    protected $validationRules = [
        'name' => 'required|max_length[20]',
        'course' => 'required|max_length[20]',
        'student_no' => 'required|max_length[20]',
        'email' => 'required|valid_email|max_length[120]'
    ];
}