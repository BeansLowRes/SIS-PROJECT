<?php $errors = session('errors') ?? []; ?>

<?php if ($errors): ?>
    <div role="alert">
        <p>Please correct these fields:</p>
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?= esc($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?= site_url('students') ?>" method="POST">
    <?= csrf_field(); ?>

    <label for="Name">Full Name</label>
    <input type="text" name="name" value="<?= old('name'); ?>">
    <label for="Course">Course</label>
    <input type="text" name="course">Course</input>
    <label for="Student Number">Student Number</label>
    <input type="text" name="student_no" value="<?= old('student_no'); ?>">
    <label for="Email">Email</label>
    <input type="text" name="email" value="<?= old('email'); ?>">

    <button type="submit">Create Student</button>
</form>