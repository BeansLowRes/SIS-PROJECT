<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>students directory</title>
</head>
<body>
    <h1> student directory</h1>
    <?php if(empty($students)): ?>
        <p> No Student Found</p>
        <?php else: ?>
            <?php foreach($students as $student): ?>
                <p>
                    <?= esc($student['name']) ?> -
                    <?= esc($student['course']) ?>
                    <?= esc($student['student_no']) ?>
                    <?= esc($student['email']) ?>
            </p>
            <?php endforeach; ?>
            <?php endif; ?>         

            